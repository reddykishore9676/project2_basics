# Project 2: Sensor Interfacing and Communication Protocols

## 1. Objective

The primary objective of this project was to develop embedded C code demonstrating proficiency in three major communication protocols: **UART (Universal Asynchronous Receiver/Transmitter)**, **I2C (Inter-Integrated Circuit)**, and **SPI (Serial Peripheral Interface)**. The project involved interfacing with a sensor via I2C and a memory device via SPI, with all results being outputted through UART for verification.

## 2. Implementation Details

The code is developed for a generic ARM Cortex-M microcontroller architecture, using mock register definitions and hardware abstraction layer (HAL) functions to illustrate the required logic and flow for each protocol.

### 2.1. UART Communication (`uart_tx_rx.c`)

The UART implementation fulfills two core requirements: periodic transmission and receive echo.

| Feature | Implementation Detail |
| :--- | :--- |
| **Initialization** | Mock registers are used to set up the UART peripheral for 9600 baud, 8 data bits, no parity, and 1 stop bit (8N1). |
| **Transmission (TX)** | The function `UART_Print` sends the string "Hello from MCU" every 1 second. The `UART_Transmit` function polls the Transmit FIFO Full (TXFF) flag to ensure data is not lost. |
| **Reception (RX Echo)** | The main loop continuously checks the Receive FIFO Empty (RXFE) flag. If a character is received, it is immediately echoed back to the terminal, prefixed with "Echo: ". |

### 2.2. I2C Sensor Interface (`i2c_sensor_read.c`)

The **MPU6050** (3-axis Accelerometer and 3-axis Gyroscope) was selected as the I2C sensor for this task. This sensor is widely used and demonstrates the ability to read multi-byte data from sequential registers.

| Feature | Implementation Detail |
| :--- | :--- |
| **Sensor Chosen** | **MPU6050** (I2C Address: 0x68) |
| **Initialization** | The `MPU6050_Init` function calls a mock `I2C_Init` and then writes `0x00` to the `PWR_MGMT_1` register (`0x6B`) to wake the device from sleep mode. |
| **Data Read** | The `MPU6050_Read_Data` function reads 14 consecutive bytes starting from the `ACCEL_XOUT_H` register (`0x3B`). This block contains all 6 axis data (Accel X, Y, Z and Gyro X, Y, Z). |
| **Data Processing** | The 16-bit raw sensor values are reconstructed by combining the high and low bytes. These values are then formatted into a readable string and printed via UART. |

### 2.3. SPI Device Interface (`spi_comm_device.c`)

The **EEPROM 25LC256** (256 Kbit Serial EEPROM) was chosen as the SPI device. This device requires precise command sequencing to perform write and read operations, including the use of a Write Enable command.

| Feature | Implementation Detail |
| :--- | :--- |
| **Device Chosen** | **EEPROM 25LC256** |
| **Initialization** | A mock `SPI_Init` function is assumed to configure the SPI peripheral for Mode 0 operation. Mock `CS_Low` and `CS_High` functions control the Chip Select line. |
| **Write Operation** | Writing a byte requires three steps: 1) Send **WREN** (Write Enable) command. 2) Send **WRITE** command, followed by the 16-bit address and the data byte. 3) Poll the Status Register using the **RDSR** command until the Write In Progress (WIP) bit is cleared, ensuring the write cycle is complete. |
| **Read Operation** | Reading a byte involves sending the **READ** command, followed by the 16-bit address. The subsequent byte received from the `SPI_Transfer` function is the data stored at that address. |
| **Verification** | The code writes a test value (`0xAB`) to a specific address (`0x0010`), reads it back, and prints a success or failure message via UART. |

## 3. Hardware and Wiring

The project requires a microcontroller (MCU) to be connected to three external components: a USB-to-Serial adapter (for UART), the MPU6050 sensor (for I2C), and the 25LC256 EEPROM (for SPI).

The general wiring scheme is illustrated in the accompanying `Wiring_Diagram.png`.

| Protocol | MCU Pins | External Component Pins |
| :--- | :--- | :--- |
| **UART** | TX, RX | USB-to-Serial RX, TX |
| **I2C** | SCL, SDA | MPU6050 SCL, SDA |
| **SPI** | SCK, MOSI, MISO, CS | 25LC256 SCK, SI, SO, CS |

## 4. Results and Verification

The functionality of the embedded code is verified by observing the output on a serial terminal. Simulated screenshots of the serial monitor output for each communication test are provided in the `Serial_Screenshots` directory.

*   **UART_Screenshot.png**: Shows the periodic "Hello from MCU" message and the successful echo of received characters.
*   **I2C_Screenshot.png**: Displays the continuously updated raw accelerometer and gyroscope data read from the MPU6050.
*   **SPI_Screenshot.png**: Confirms the successful write and read operation to the EEPROM, demonstrating the integrity of the SPI protocol implementation.

## 5. Submission Requirements Checklist

The following files and directories are included in the final submission package:

| File/Directory | Description | Status |
| :--- | :--- | :--- |
| `uart_tx_rx.c` | Embedded C code for UART TX/RX and echo. | **Complete** |
| `i2c_sensor_read.c` | Embedded C code for I2C interface with MPU6050. | **Complete** |
| `spi_comm_device.c` | Embedded C code for SPI interface with 25LC256 EEPROM. | **Complete** |
| `Wiring_Diagram.png` | Visual representation of the hardware connections. | **Complete** |
| `/Serial_Screenshots` | Directory containing simulated serial monitor outputs. | **Complete** |
| `Report.pdf` | This project report. | **Pending Conversion** |
| `GitHub Link.txt` | Placeholder for the project's GitHub repository link. | **Pending** |

---
*Note: The C code files contain mock hardware definitions and functions, as the target microcontroller is not specified. These serve as a robust template for direct porting to any specific embedded platform's HAL.*
